var canvas = document.getElementById('rear');
var ctx = canvas.getContext('2d');
var width = window.CANVAS_W || 912, height = window.CANVAS_H || 596;
var started = Date.now(), taps = 0;
canvas.addEventListener('click', function () { taps++; });
function draw() {
  ctx.fillStyle = '#163858'; ctx.fillRect(0, 0, width, height);
  ctx.fillStyle = '#ffffff'; ctx.font = 'bold 28px sans-serif';
  ctx.fillText('动态更新 · A', width * 0.34, 70);
  ctx.font = 'bold 110px sans-serif'; ctx.fillText('A', width * 0.46, height * 0.52);
  ctx.font = '22px sans-serif';
  ctx.fillText('运行 ' + Math.floor((Date.now() - started) / 1000) + ' 秒 · 点击 ' + taps, width * 0.34, height * 0.76);
  requestAnimationFrame(draw);
}
console.log('RearCardBridgeDemo A started');
requestAnimationFrame(draw);
